import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.lab8.MainScreen
import com.example.lab8.PersonajesPi
import com.example.lab8.ui.characters.PersonajesP

@Composable
fun Navegacion() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "main"
    ) {
        composable("main") {
            MainScreen(
                onStartClick = {
                    navController.navigate("personajes") {
                        popUpTo("main") { inclusive = true }
                    }
                }
            )
        }

        composable("personajes") {
            PersonajesP(
                onCharacterClick = { id ->
                    navController.navigate("personajesPi/$id")
                }
            )
        }

        composable("personajesPi/{id}") { backStackEntry ->
            val id = backStackEntry.arguments?.getString("id")?.toIntOrNull() ?: 0
            PersonajesPi(
                characterId = id,
                onBackClick = { navController.popBackStack() }
            )
        }
    }
}