package com.example.lab8.ui.characters

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.lab8.Datos
import com.example.lab8.PersonajesViewModel

@Composable
fun PersonajesP(
    onCharacterClick: (Int) -> Unit,
    viewModel: PersonajesViewModel = viewModel()
) {
    val personajes by viewModel.personajes.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(personajes) { p ->
            PersonajeRow(personaje = p, onClick = { onCharacterClick(p.id) })
        }
    }
}

@Composable
fun PersonajeRow(personaje: Datos.Character, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(8.dp),
        horizontalArrangement = Arrangement.Start
    ) {
        AsyncImage(model = personaje.image, contentDescription = personaje.name, modifier = Modifier.size(56.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(text = personaje.name)
            Text(text = "${personaje.species} • ${personaje.status}")
        }
    }
}