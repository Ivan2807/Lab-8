package com.example.lab8

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonajesPi(
    characterId: Int,
    onBackClick: () -> Unit,
    viewModel: PersonajeDetalleViewModel = viewModel()
) {
    viewModel.loadCharacter(characterId)
    val personaje = viewModel.personaje.collectAsState().value

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        TopAppBar(
            title = { Text("Character details") },
            navigationIcon = {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "back")
                }
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        personaje?.let { p ->
            AsyncImage(model = p.image, contentDescription = p.name, modifier = Modifier.size(160.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = p.name)
            Text(text = "Species: ${p.species}")
            Text(text = "Status: ${p.status}")
            Text(text = "Gender: ${p.gender}")
        } ?: run {
            Text("Personaje no encontrado")
        }
    }
}