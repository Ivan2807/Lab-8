package com.example.lab9

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

// ---------------- DATOS PARA LOCACIONES ----------------
data class Location(
    val id: Int,
    val name: String,
    val type: String,
    val dimension: String
)

class LocationDb {
    private val locations = listOf(
        Location(1, "Earth (C-137)", "Planet", "Dimension C-137"),
        Location(2, "Abadango", "Cluster", "Unknown"),
        Location(3, "Citadel of Ricks", "Space station", "Unknown"),
        Location(4, "Worldender’s lair", "Planet", "Unknown"),
        Location(5, "Anatomy Park", "Microverse", "Dimension C-137"),
        Location(6, "Interdimensional Cable", "TV", "Unknown")
    )

    fun getAllLocations(): List<Location> = locations
    fun getLocationById(id: Int): Location? = locations.find { it.id == id }
}

class LocationsViewModel : ViewModel() {
    private val _locations = MutableStateFlow<List<Location>>(emptyList())
    val locations = _locations.asStateFlow()

    init {
        _locations.value = LocationDb().getAllLocations()
    }
}

class LocationDetalleViewModel : ViewModel() {
    private val _location = MutableStateFlow<Location?>(null)
    val location = _location.asStateFlow()

    fun loadLocation(id: Int) {
        _location.value = LocationDb().getLocationById(id)
    }
}

// ---------------- PANTALLAS ----------------

@Composable
fun NavegacionLab9(
    onLogout: () -> Unit
) {
    val navController = rememberNavController()
    var selectedItem by remember { mutableStateOf("characters") }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Home, contentDescription = "Characters") },
                    label = { Text("Characters") },
                    selected = selectedItem == "characters",
                    onClick = {
                        selectedItem = "characters"
                        navController.navigate("characters") {
                            popUpTo("characters") { inclusive = true }
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Place, contentDescription = "Locations") },
                    label = { Text("Locations") },
                    selected = selectedItem == "locations",
                    onClick = {
                        selectedItem = "locations"
                        navController.navigate("locations") {
                            popUpTo("locations") { inclusive = true }
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.AccountCircle, contentDescription = "Profile") },
                    label = { Text("Profile") },
                    selected = selectedItem == "profile",
                    onClick = {
                        selectedItem = "profile"
                        navController.navigate("profile") {
                            popUpTo("profile") { inclusive = true }
                        }
                    }
                )
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "characters",
            modifier = Modifier.padding(padding)
        ) {
            // -------- Characters Graph --------
            composable("characters") {
                PersonajesP(onCharacterClick = { id ->
                    navController.navigate("characterDetail/$id")
                })
            }
            composable("characterDetail/{id}") { backStackEntry ->
                val id = backStackEntry.arguments?.getString("id")?.toIntOrNull() ?: 0
                PersonajesPi(characterId = id, onBackClick = { navController.popBackStack() })
            }

            // -------- Locations Graph --------
            composable("locations") {
                LocationsScreen(onLocationClick = { id ->
                    navController.navigate("locationDetail/$id")
                })
            }
            composable("locationDetail/{id}") { backStackEntry ->
                val id = backStackEntry.arguments?.getString("id")?.toIntOrNull() ?: 0
                LocationDetailScreen(locationId = id, onBackClick = { navController.popBackStack() })
            }

            // -------- Profile --------
            composable("profile") {
                ProfileScreen(onLogoutClick = {
                    onLogout()
                })
            }
        }
    }
}

@Composable
fun LocationsScreen(
    onLocationClick: (Int) -> Unit,
    viewModel: LocationsViewModel = viewModel()
) {
    val locations by viewModel.locations.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(locations) { loc ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onLocationClick(loc.id) }
                    .padding(8.dp),
                horizontalArrangement = Arrangement.Start
            ) {
                Column {
                    Text(text = loc.name, style = MaterialTheme.typography.titleMedium)
                    Text(text = "Tipo: ${loc.type}")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationDetailScreen(
    locationId: Int,
    onBackClick: () -> Unit,
    viewModel: LocationDetalleViewModel = viewModel()
) {
    viewModel.loadLocation(locationId)
    val location = viewModel.location.collectAsState().value

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        TopAppBar(
            title = { Text("Location details") },
            navigationIcon = {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "back")
                }
            }
        )
        Spacer(modifier = Modifier.height(16.dp))
        location?.let { l ->
            Text("ID: ${l.id}")
            Text("Nombre: ${l.name}")
            Text("Tipo: ${l.type}")
            Text("Dimensión: ${l.dimension}")
        } ?: run {
            Text("Locación no encontrada")
        }
    }
}

@Composable
fun ProfileScreen(onLogoutClick: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = android.R.drawable.sym_def_app_icon),
            contentDescription = "Imagen de perfil",
            modifier = Modifier.size(120.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text("Ivan Morataya")
        Text("Carne: 16667")
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onLogoutClick) {
            Text("Cerrar sesión")
        }
    }
}
