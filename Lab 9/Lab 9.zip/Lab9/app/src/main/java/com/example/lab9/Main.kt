package com.example.lab9

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

@Composable
fun MainScreen(
    onStartClick: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        AsyncImage(
            model = "https://logos-world.net/wp-content/uploads/2022/01/Rick-And-Morty-Logo.png",
            contentDescription = "Rick and Morty Logo",
            modifier = Modifier
                .height(160.dp)
                .fillMaxWidth()
        )

        Button(
            onClick = onStartClick,
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Text("Empezar")
        }

        Text("Ivan Morataya - 16667")
    }
}