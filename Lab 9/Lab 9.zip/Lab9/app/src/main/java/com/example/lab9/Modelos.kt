package com.example.lab9

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class PersonajesViewModel : ViewModel() {
    private val _personajes = MutableStateFlow<List<Datos.Character>>(emptyList())
    val personajes = _personajes.asStateFlow()

    init { _personajes.value = Datos().getAllCharacters() }
}

class PersonajeDetalleViewModel : ViewModel() {
    private val _personaje = MutableStateFlow<Datos.Character?>(null)
    val personaje = _personaje.asStateFlow()

    fun loadCharacter(id: Int) {
        _personaje.value = Datos().getCharacterById(id)
    }
}